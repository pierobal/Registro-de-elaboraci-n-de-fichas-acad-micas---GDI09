CREATE DATABASE  IF NOT EXISTS `grupo_mega_fichas` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `grupo_mega_fichas`;
-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: grupo_mega_fichas
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ficha_academica`
--

DROP TABLE IF EXISTS `ficha_academica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ficha_academica` (
  `Id_ficha` int NOT NULL,
  `DNI` char(8) NOT NULL,
  `Id_guia` int NOT NULL,
  `Id_material` int NOT NULL,
  `Curso` varchar(25) NOT NULL,
  `Fecha_envio_ficha` date NOT NULL,
  `Estado` varchar(10) NOT NULL DEFAULT 'Activo',
  PRIMARY KEY (`Id_ficha`),
  KEY `fk_ficha_profesor` (`DNI`),
  KEY `fk_ficha_guia` (`Id_guia`),
  KEY `fk_ficha_material` (`Id_material`),
  KEY `idx_ficha_curso` (`Curso`),
  CONSTRAINT `fk_ficha_guia` FOREIGN KEY (`Id_guia`) REFERENCES `guia_academica` (`Id_guia`),
  CONSTRAINT `fk_ficha_material` FOREIGN KEY (`Id_material`) REFERENCES `material_apoyo` (`Id_material`),
  CONSTRAINT `fk_ficha_profesor` FOREIGN KEY (`DNI`) REFERENCES `profesor` (`DNI`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ficha_academica`
--

LOCK TABLES `ficha_academica` WRITE;
/*!40000 ALTER TABLE `ficha_academica` DISABLE KEYS */;
INSERT INTO `ficha_academica` VALUES (2,'72741300',32,1001,'Matemàtica','2026-07-10','Inactivo'),(3,'72741300',32,1001,'Matemàtica','2026-07-10','Activo'),(9730,'72741300',31,1001,'Química','2026-07-10','Inactivo'),(9731,'72741300',31,1002,'Química','2026-07-03','Inactivo'),(9732,'72741300',32,1001,'Química','2026-07-10','Activo'),(9733,'72741300',33,1001,'Química','2026-07-17','Activo'),(9734,'72741300',34,1002,'Química','2026-07-24','Activo'),(9735,'72741300',35,1002,'Química','2026-07-31','Activo'),(9736,'72741300',36,1002,'Química','2026-08-11','Activo'),(9737,'72741300',37,1003,'Química','2026-08-14','Activo'),(9738,'45128736',39,1004,'Matemática','2026-07-03','Activo'),(9739,'45128736',40,1004,'Matemática','2026-07-10','Activo'),(9740,'46239871',42,1005,'Física','2026-07-03','Activo'),(9741,'46239871',43,1005,'Física','2026-07-10','Activo'),(9742,'47315624',44,1006,'Lenguaje','2026-07-03','Activo');
/*!40000 ALTER TABLE `ficha_academica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ficha_tema`
--

DROP TABLE IF EXISTS `ficha_tema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ficha_tema` (
  `Id_ficha` int NOT NULL,
  `Tema` varchar(25) NOT NULL,
  PRIMARY KEY (`Id_ficha`,`Tema`),
  CONSTRAINT `fk_fichatema_ficha` FOREIGN KEY (`Id_ficha`) REFERENCES `ficha_academica` (`Id_ficha`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ficha_tema`
--

LOCK TABLES `ficha_tema` WRITE;
/*!40000 ALTER TABLE `ficha_tema` DISABLE KEYS */;
INSERT INTO `ficha_tema` VALUES (9731,'Soluciones'),(9732,'Estructura del átomo'),(9733,'Enlaces químicos'),(9734,'Compuestos inorgánicos'),(9734,'Óxidos'),(9735,'Compuestos inorgánicos'),(9735,'Hidróxidos'),(9736,'Ácidos'),(9736,'Compuestos inorgánicos'),(9737,'Compuestos inorgánicos'),(9737,'Sales'),(9738,'Ecuaciones lineales'),(9739,'Sistemas de ecuaciones'),(9740,'Cinemática'),(9741,'MRUV'),(9742,'Comprensión lectora');
/*!40000 ALTER TABLE `ficha_tema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guia_academica`
--

DROP TABLE IF EXISTS `guia_academica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guia_academica` (
  `Id_guia` int NOT NULL,
  `Fecha_inicio` date NOT NULL,
  `Fecha_fin` date NOT NULL,
  `Desarrollo_de_tema` varchar(200) NOT NULL,
  `Fecha_envio` date NOT NULL,
  `Estado` varchar(10) NOT NULL DEFAULT 'Activo',
  PRIMARY KEY (`Id_guia`),
  KEY `idx_guia_inicio` (`Fecha_inicio`),
  CONSTRAINT `ck_guia_fechas` CHECK ((`Fecha_fin` >= `Fecha_inicio`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guia_academica`
--

LOCK TABLES `guia_academica` WRITE;
/*!40000 ALTER TABLE `guia_academica` DISABLE KEYS */;
INSERT INTO `guia_academica` VALUES (1,'2026-07-15','2026-07-16','Modelo actual del átomo. Núcleo. Configuración electrónica','2026-06-27','Inactivo'),(2,'2026-07-14','2026-07-17','Modelo actual del átomo. Núcleo. Configuración electrónica','2026-06-26','Inactivo'),(3,'2026-07-14','2026-07-17','Modelo actual del átomo. Núcleo. Configuración electrónica','2026-06-26','Activo'),(31,'2026-07-06','2026-07-10','Definición. Concentraciones: molaridad y normalidad. Neutralización ácido-base','2026-06-26','Inactivo'),(32,'2026-07-13','2026-07-17','Modelo actual del átomo. Núcleo. Configuración electrónica','2026-06-26','Activo'),(33,'2026-07-20','2026-07-24','Enlaces interatómicos: iónico, covalente y metálico. Fuerzas intermoleculares','2026-06-26','Activo'),(34,'2026-07-27','2026-07-31','Óxidos básicos y óxidos ácidos. Nomenclatura','2026-06-26','Activo'),(35,'2026-08-03','2026-08-07','Hidróxidos. Nomenclatura y propiedades','2026-07-27','Activo'),(36,'2026-08-10','2026-08-14','Ácidos oxácidos e hidrácidos. Nomenclatura','2026-07-27','Activo'),(37,'2026-08-17','2026-08-21','Sales oxisales y haloideas. Nomenclatura','2026-07-27','Activo'),(38,'2026-08-24','2026-08-28','Definición. Ecuación química. Clasificación. Reacciones de reducción y oxidación (Redox)','2026-07-27','Activo'),(39,'2026-07-06','2026-07-10','Ecuaciones de primer grado con una incógnita','2026-06-26','Activo'),(40,'2026-07-13','2026-07-17','Sistemas de ecuaciones lineales 2x2. Métodos de resolución','2026-06-26','Activo'),(41,'2026-07-20','2026-07-24','Definición de función. Dominio y rango','2026-06-26','Activo'),(42,'2026-07-06','2026-07-10','Movimiento rectilíneo uniforme. Gráficas posición-tiempo','2026-06-26','Activo'),(43,'2026-07-13','2026-07-17','Movimiento rectilíneo uniformemente variado','2026-06-26','Activo'),(44,'2026-07-06','2026-07-10','Estrategias de comprensión lectora. Inferencias','2026-06-26','Activo');
/*!40000 ALTER TABLE `guia_academica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guia_tema`
--

DROP TABLE IF EXISTS `guia_tema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guia_tema` (
  `Id_guia` int NOT NULL,
  `Tema` varchar(25) NOT NULL,
  PRIMARY KEY (`Id_guia`,`Tema`),
  CONSTRAINT `fk_guiatema_guia` FOREIGN KEY (`Id_guia`) REFERENCES `guia_academica` (`Id_guia`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guia_tema`
--

LOCK TABLES `guia_tema` WRITE;
/*!40000 ALTER TABLE `guia_tema` DISABLE KEYS */;
INSERT INTO `guia_tema` VALUES (31,'Soluciones'),(32,'Estructura del átomo'),(33,'Enlaces químicos'),(34,'Compuestos inorgánicos'),(34,'Óxidos'),(35,'Compuestos inorgánicos'),(35,'Hidróxidos'),(36,'Ácidos'),(36,'Compuestos inorgánicos'),(37,'Compuestos inorgánicos'),(37,'Sales'),(38,'Reacciones químicas'),(38,'Redox'),(39,'Ecuaciones lineales'),(40,'Sistemas de ecuaciones'),(41,'Funciones'),(42,'Cinemática'),(43,'MRUV'),(44,'Comprensión lectora');
/*!40000 ALTER TABLE `guia_tema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `historial_bajas`
--

DROP TABLE IF EXISTS `historial_bajas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `historial_bajas` (
  `id_baja` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `nombre_usuario` varchar(50) NOT NULL,
  `rol_usuario` varchar(20) NOT NULL,
  `administrador` varchar(50) NOT NULL,
  `fecha_baja` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `motivo` varchar(100) NOT NULL,
  `observaciones` text,
  PRIMARY KEY (`id_baja`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `historial_bajas_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historial_bajas`
--

LOCK TABLES `historial_bajas` WRITE;
/*!40000 ALTER TABLE `historial_bajas` DISABLE KEYS */;
INSERT INTO `historial_bajas` VALUES (1,3,'yampier','USUARIO','admin','2026-11-19 18:56:38','Renuncia voluntaria','Prueba de funcionamiento del sistema'),(2,3,'yampier','USUARIO','admin','2026-11-19 19:14:02','Renuncia voluntaria','prueba del sistema'),(3,3,'yampier','USUARIO','admin','2026-11-19 19:25:50','Renuncia voluntaria','prueba del sistema'),(4,4,'luis','USUARIO','admin','2026-11-19 19:57:31','Renuncia voluntaria','prueba'),(5,5,'lucas','USUARIO','admin','2026-11-19 20:06:42','Renuncia voluntaria','ejemplo');
/*!40000 ALTER TABLE `historial_bajas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material_apoyo`
--

DROP TABLE IF EXISTS `material_apoyo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_apoyo` (
  `Id_material` int NOT NULL,
  `Curso` varchar(25) NOT NULL,
  `Tipo_material` varchar(10) NOT NULL,
  `Autor` varchar(40) NOT NULL,
  `Estado` varchar(10) NOT NULL DEFAULT 'Activo',
  `fecha_baja` datetime DEFAULT NULL,
  PRIMARY KEY (`Id_material`),
  CONSTRAINT `ck_material_tipo` CHECK ((`Tipo_material` in (_utf8mb4'Teórico',_utf8mb4'Práctico')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_apoyo`
--

LOCK TABLES `material_apoyo` WRITE;
/*!40000 ALTER TABLE `material_apoyo` DISABLE KEYS */;
INSERT INTO `material_apoyo` VALUES (1,'Química','Teórico','Pre Católica UCSM','Inactivo',NULL),(2,'Química','Pràctico','Pre Católica UCSM','Inactivo',NULL),(3,'Química','Pràctico','Pre Católica UCSM','Activo',NULL),(1001,'Química','Práctico','CEPRUNSA','Inactivo',NULL),(1002,'Química','Teórico','Pre Católica UCSM','Activo',NULL),(1003,'Química','Teórico','Academia Grupo Mega','Activo',NULL),(1004,'Matemática','Práctico','CEPRUNSA','Activo',NULL),(1005,'Física','Práctico','CEPRUNSA','Activo',NULL),(1006,'Lenguaje','Teórico','Pre Católica UCSM','Activo',NULL);
/*!40000 ALTER TABLE `material_apoyo` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_fecha_baja_material` BEFORE UPDATE ON `material_apoyo` FOR EACH ROW BEGIN
    IF OLD.Estado = 'Activo' AND NEW.Estado = 'Inactivo' THEN
        SET NEW.fecha_baja = CURRENT_TIMESTAMP;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `material_capacidad`
--

DROP TABLE IF EXISTS `material_capacidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_capacidad` (
  `Id_material` int NOT NULL,
  `Capacidad` varchar(150) NOT NULL,
  PRIMARY KEY (`Id_material`,`Capacidad`),
  CONSTRAINT `fk_matcap_material` FOREIGN KEY (`Id_material`) REFERENCES `material_apoyo` (`Id_material`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_capacidad`
--

LOCK TABLES `material_capacidad` WRITE;
/*!40000 ALTER TABLE `material_capacidad` DISABLE KEYS */;
INSERT INTO `material_capacidad` VALUES (1001,'Explica el mundo físico basándose en conocimiento sobre la materia'),(1001,'Indaga mediante métodos científicos para construir sus conocimientos'),(1002,'Explica el mundo físico basándose en conocimiento sobre la materia'),(1003,'Explica el mundo físico basándose en conocimiento sobre la materia'),(1004,'Resuelve problemas de regularidad, equivalencia y cambio'),(1005,'Explica el mundo físico basándose en conocimiento sobre el movimiento'),(1006,'Lee diversos tipos de textos escritos en su lengua materna');
/*!40000 ALTER TABLE `material_capacidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material_conocimiento`
--

DROP TABLE IF EXISTS `material_conocimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_conocimiento` (
  `Id_material` int NOT NULL,
  `Conocimiento` varchar(100) NOT NULL,
  PRIMARY KEY (`Id_material`,`Conocimiento`),
  CONSTRAINT `fk_matcon_material` FOREIGN KEY (`Id_material`) REFERENCES `material_apoyo` (`Id_material`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_conocimiento`
--

LOCK TABLES `material_conocimiento` WRITE;
/*!40000 ALTER TABLE `material_conocimiento` DISABLE KEYS */;
INSERT INTO `material_conocimiento` VALUES (1001,'Enlaces químicos'),(1001,'Estructura del átomo'),(1001,'Materia'),(1002,'Compuestos inorgánicos'),(1002,'Soluciones'),(1003,'Estequiometría'),(1003,'Reacciones químicas'),(1004,'Ecuaciones lineales'),(1004,'Funciones'),(1005,'Cinemática'),(1005,'MRUV'),(1006,'Comprensión lectora'),(1006,'Plan de redacción');
/*!40000 ALTER TABLE `material_conocimiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profesor`
--

DROP TABLE IF EXISTS `profesor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profesor` (
  `DNI` char(8) NOT NULL,
  `Nombre` varchar(60) NOT NULL,
  `Apellido` varchar(60) NOT NULL,
  `Estado` varchar(10) NOT NULL DEFAULT 'Activo',
  PRIMARY KEY (`DNI`),
  CONSTRAINT `ck_profesor_dni` CHECK (regexp_like(`DNI`,_utf8mb4'^[0-9]{8}$'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profesor`
--

LOCK TABLES `profesor` WRITE;
/*!40000 ALTER TABLE `profesor` DISABLE KEYS */;
INSERT INTO `profesor` VALUES ('11111111','Carlos Alberto','Ramirez Lopez','Inactivo'),('12345678','oliver yampiero','mendoza quispe','Inactivo'),('22222222','Oliver Yampiero','Mendoza Quispe','Inactivo'),('33333333','Yampiero Oliver','Quispe Mendoza','Activo'),('45128736','Juan Carlos','Gonzales Palacios','Activo'),('46239871','Rosa Elena','Quispe Mamani','Activo'),('47315624','Carla Patricia','Ramos Salas','Activo'),('72741300','Mauricio Daniel','Guillen Meza','Activo');
/*!40000 ALTER TABLE `profesor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `id_usuario` int NOT NULL AUTO_INCREMENT,
  `nombre_usuario` varchar(50) NOT NULL,
  `contrasena` varchar(255) NOT NULL,
  `rol` enum('ADMIN','USUARIO') NOT NULL DEFAULT 'USUARIO',
  `estado` enum('ACTIVO','INACTIVO','BAJA') NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `nombre_usuario` (`nombre_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'admin','pbkdf2$120000$MISSKpHpXFjdc0SBOYn59Q==$HAPw2ywJvoOTBMV4cvg6LvZq2UnC2iUAfDlfihBA8Zk=','ADMIN','ACTIVO'),(2,'oliver','pbkdf2$120000$gTqWS1YfZ3pkoBQ9ub/o3g==$I51+ILpGNWHFGipenPKadZu7AOp7G1BksOeu1XiL1c0=','USUARIO','ACTIVO'),(3,'yampier','pbkdf2$120000$Qb+0Drc3uMwo9qSwP3y5Eg==$fDYSIyCvlEN/gi6S80E4u8BRd/Ou4Z873MPuU6RXgr0=','USUARIO','BAJA'),(4,'luis','pbkdf2$120000$yZBWVNU2pwHfMH7ZH7/h7A==$ujIviYpOB+HC2QsLDYdxFvX363jwo3ssmBp6Q/DL+Eo=','USUARIO','BAJA'),(5,'lucas','pbkdf2$120000$H+N7sOCx7olFT2hzOFo7kQ==$oQn2DnHzvfA5U5Dog9dMi8IbaO24gZoWe7VI9OFOcs4=','USUARIO','BAJA'),(6,'felipe','pbkdf2$120000$O6yS7wZWJAndzFTFE0dwkQ==$TS2IrqvN9hmWAeScNAgfbMxGcVTdjVAv8jENnAE+efo=','USUARIO','ACTIVO');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'grupo_mega_fichas'
--
/*!50003 DROP PROCEDURE IF EXISTS `sp_actualizar_profesor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_actualizar_profesor`(
    IN p_DNI CHAR(8),
    IN p_Nombre VARCHAR(60),
    IN p_Apellido VARCHAR(60)
)
BEGIN
    UPDATE Profesor
    SET Nombre = p_Nombre,
        Apellido = p_Apellido
    WHERE DNI = p_DNI
      AND Estado = 'Activo';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_buscar_profesor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_buscar_profesor`(
    IN p_DNI CHAR(8)
)
BEGIN
    SELECT DNI, Nombre, Apellido
    FROM Profesor
    WHERE DNI = p_DNI
      AND Estado = 'Activo';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_desactivar_profesor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_desactivar_profesor`(
    IN p_DNI CHAR(8)
)
BEGIN
    UPDATE Profesor
    SET Estado = 'Inactivo'
    WHERE DNI = p_DNI
      AND Estado = 'Activo';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_listar_fichas` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_listar_fichas`()
BEGIN
    SELECT * FROM Ficha_Academica
    WHERE Estado = 'Activo'
    ORDER BY Id_ficha;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_listar_guias` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_listar_guias`()
BEGIN
    SELECT * FROM Guia_Academica
    WHERE Estado = 'Activo'
    ORDER BY Id_guia;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_listar_materiales` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_listar_materiales`()
BEGIN
    SELECT * FROM Material_Apoyo
    WHERE Estado = 'Activo'
    ORDER BY Id_material;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_listar_profesores` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_listar_profesores`()
BEGIN
    SELECT * FROM Profesor
    WHERE Estado = 'Activo'
    ORDER BY Apellido, Nombre;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_registrar_profesor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_registrar_profesor`(
    IN p_DNI CHAR(8),
    IN p_Nombre VARCHAR(60),
    IN p_Apellido VARCHAR(60)
)
BEGIN
    INSERT INTO Profesor (DNI, Nombre, Apellido)
    VALUES (p_DNI, p_Nombre, p_Apellido);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_reporte_fichas_completas` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_reporte_fichas_completas`()
BEGIN
    SELECT
        f.Id_ficha,
        f.Curso,
        f.Fecha_envio_ficha,
        p.DNI,
        CONCAT(p.Nombre, ' ', p.Apellido) AS Profesor,
        g.Desarrollo_de_tema AS Tema_Guia,
        m.Tipo_material,
        m.Autor
    FROM Ficha_Academica f
    INNER JOIN Profesor p
        ON f.DNI = p.DNI
    INNER JOIN Guia_Academica g
        ON f.Id_guia = g.Id_guia
    INNER JOIN Material_Apoyo m
        ON f.Id_material = m.Id_material
    ORDER BY f.Id_ficha;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_reporte_fichas_por_curso` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_reporte_fichas_por_curso`()
BEGIN
    SELECT
        Curso,
        COUNT(*) AS Total_Fichas,
        MIN(Fecha_envio_ficha) AS Primera_Fecha,
        MAX(Fecha_envio_ficha) AS Ultima_Fecha
    FROM Ficha_Academica
    GROUP BY Curso
    ORDER BY Curso;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_reporte_fichas_profesor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_reporte_fichas_profesor`()
BEGIN
    SELECT
        p.DNI,
        CONCAT(p.Nombre, ' ', p.Apellido) AS Profesor,
        f.Id_ficha,
        f.Curso,
        f.Fecha_envio_ficha,
        f.Id_guia,
        f.Id_material
    FROM Profesor p
    INNER JOIN Ficha_Academica f
        ON p.DNI = f.DNI
    ORDER BY p.Apellido, f.Id_ficha;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_reporte_fichas_temas` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_reporte_fichas_temas`()
BEGIN
    SELECT
        f.Id_ficha,
        f.Curso,
        f.Fecha_envio_ficha,
        ft.Tema
    FROM Ficha_Academica f
    INNER JOIN Ficha_Tema ft
        ON f.Id_ficha = ft.Id_ficha
    ORDER BY f.Id_ficha;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_reporte_guias_por_fecha` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_reporte_guias_por_fecha`()
BEGIN
    SELECT
        Id_guia,
        Fecha_inicio,
        Fecha_fin,
        Desarrollo_de_tema,
        Fecha_envio
    FROM Guia_Academica
    WHERE Fecha_inicio BETWEEN '2026-07-01' AND '2026-08-31'
    ORDER BY Fecha_inicio;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_reporte_guias_temas` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_reporte_guias_temas`()
BEGIN
    SELECT
        g.Id_guia,
        g.Fecha_inicio,
        g.Fecha_fin,
        g.Desarrollo_de_tema,
        gt.Tema
    FROM Guia_Academica g
    INNER JOIN Guia_Tema gt
        ON g.Id_guia = gt.Id_guia
    ORDER BY g.Id_guia;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_reporte_materiales_capacidades` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_reporte_materiales_capacidades`()
BEGIN
    SELECT
        m.Id_material,
        m.Curso,
        m.Tipo_material,
        m.Autor,
        mc.Capacidad
    FROM Material_Apoyo m
    INNER JOIN Material_Capacidad mc
        ON m.Id_material = mc.Id_material
    ORDER BY m.Id_material;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_reporte_materiales_conocimientos` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_reporte_materiales_conocimientos`()
BEGIN
    SELECT
        m.Id_material,
        m.Curso,
        m.Tipo_material,
        m.Autor,
        mc.Conocimiento
    FROM Material_Apoyo m
    INNER JOIN Material_Conocimiento mc
        ON m.Id_material = mc.Id_material
    ORDER BY m.Id_material;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_reporte_materiales_por_tipo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_reporte_materiales_por_tipo`()
BEGIN
    SELECT
        Tipo_material,
        COUNT(*) AS Total_Materiales,
        GROUP_CONCAT(
            CONCAT(Id_material, ' - ', Curso, ' - ', Autor)
            SEPARATOR '; '
        ) AS Materiales
    FROM Material_Apoyo
    GROUP BY Tipo_material
    ORDER BY Tipo_material;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_reporte_resumen_profesores` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_reporte_resumen_profesores`()
BEGIN
    SELECT
        p.DNI,
        CONCAT(p.Nombre, ' ', p.Apellido) AS Profesor,
        COUNT(f.Id_ficha) AS Total_Fichas,
        COUNT(DISTINCT f.Curso) AS Total_Cursos
    FROM Profesor p
    LEFT JOIN Ficha_Academica f
        ON p.DNI = f.DNI
    GROUP BY p.DNI, p.Nombre, p.Apellido
    ORDER BY Profesor;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-19 23:57:32
