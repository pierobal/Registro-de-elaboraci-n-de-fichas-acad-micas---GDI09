
package proyecto_gdi;

public class Main {

    public static void main(String[] args) {

        java.awt.EventQueue.invokeLater(() -> {
            VentanaLogin ventana = new VentanaLogin();
            ventana.setLocationRelativeTo(null);
            ventana.setVisible(true);
        });

    }
}
