
package proyecto_gdi;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;

public class EstiloSistema {

    private static final Color AZUL = new Color(30, 58, 95);
    private static final Color AZUL_HOVER = new Color(48, 91, 140);
    private static final Color FONDO = new Color(245, 247, 250);
    private static final Color BLANCO = Color.WHITE;
    private static final Color TEXTO = new Color(45, 55, 72);
    private static final Color BORDE = new Color(215, 222, 232);

    public static void aplicar(JFrame ventana) {

        ventana.getContentPane().setBackground(FONDO);
        ventana.getContentPane().setFont(
                new Font("Segoe UI", Font.PLAIN, 14));

        aplicarEstilo(ventana.getContentPane());

        ventana.setLocationRelativeTo(null);
    }

    private static void aplicarEstilo(Container contenedor) {

        for (Component c : contenedor.getComponents()) {

            if (c instanceof JButton boton) {

                boton.setBackground(AZUL);
                boton.setForeground(BLANCO);
                boton.setFont(new Font("Segoe UI", Font.BOLD, 13));
                boton.setFocusPainted(false);
                boton.setOpaque(true);
                boton.setBorder(new EmptyBorder(9, 15, 9, 15));
                boton.setCursor(new Cursor(Cursor.HAND_CURSOR));

                boton.addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseEntered(java.awt.event.MouseEvent e) {
                        boton.setBackground(AZUL_HOVER);
                    }

                    public void mouseExited(java.awt.event.MouseEvent e) {
                        boton.setBackground(AZUL);
                    }
                });

            } else if (c instanceof JLabel etiqueta) {

    etiqueta.setForeground(AZUL);

            } else if (c instanceof JTextField campo) {

                campo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
                campo.setForeground(TEXTO);
                campo.setBackground(BLANCO);
                campo.setBorder(new CompoundBorder(
                        new LineBorder(BORDE, 1, true),
                        new EmptyBorder(6, 9, 6, 9)));

            } else if (c instanceof JTextArea area) {

                area.setFont(new Font("Segoe UI", Font.PLAIN, 14));
                area.setForeground(TEXTO);
                area.setBackground(BLANCO);

            } else if (c instanceof JComboBox<?> combo) {

                combo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
                combo.setBackground(BLANCO);
                combo.setForeground(TEXTO);

            } else if (c instanceof JTable tabla) {

                tabla.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                tabla.setRowHeight(27);
                tabla.setForeground(TEXTO);
                tabla.setBackground(BLANCO);
                tabla.setGridColor(BORDE);
                tabla.setSelectionBackground(
                        new Color(220, 232, 247));
                tabla.setSelectionForeground(AZUL);

                JTableHeader encabezado = tabla.getTableHeader();
                encabezado.setBackground(AZUL);
                encabezado.setForeground(BLANCO);
                encabezado.setFont(
                        new Font("Segoe UI", Font.BOLD, 13));
                encabezado.setPreferredSize(new Dimension(0, 34));

            } else if (c instanceof JScrollPane scroll) {

                scroll.setBorder(new LineBorder(BORDE, 1, true));
                scroll.getViewport().setBackground(BLANCO);

            } else if (c instanceof JPanel panel) {

                panel.setBackground(FONDO);
            }

            if (c instanceof Container interno) {
                aplicarEstilo(interno);
            }
        }
    }
}
