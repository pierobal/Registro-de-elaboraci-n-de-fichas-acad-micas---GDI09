
package proyecto_gdi;

import com.lowagie.text.Document;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Element;
import com.lowagie.text.PageSize;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.draw.LineSeparator;
import com.lowagie.text.pdf.BaseFont;
import java.awt.Color;

import java.io.File;
import java.io.FileOutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class GeneradorPDF {

    public static String generarPDF(
            String nombreUsuario,
            String rol,
            String administrador,
            String motivo,
            String observaciones,
            LocalDateTime fecha) throws Exception {

        String carpeta = System.getProperty("user.home")
                + File.separator + "Documents"
                + File.separator + "Reportes_Bajas";

        File directorio = new File(carpeta);

        if (!directorio.exists() && !directorio.mkdirs()) {
            throw new Exception("No se pudo crear la carpeta de reportes.");
        }

        String nombreArchivo = "Baja_" + nombreUsuario + "_"
                + fecha.format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"))
                + ".pdf";

        String ruta = carpeta + File.separator + nombreArchivo;

        Document documento = new Document(PageSize.A4, 50, 50, 50, 50);

        try {
            PdfWriter.getInstance(
                    documento,
                    new FileOutputStream(ruta)
            );

            documento.addTitle("Constancia de baja de usuario");
            documento.addAuthor("Sistema de Gestión Académica");

            documento.open();

            Color azul = new Color(31, 78, 121);
            Color gris = new Color(242, 245, 248);
            Color texto = new Color(55, 65, 81);

            Font titulo = FontFactory.getFont(
                    FontFactory.HELVETICA_BOLD, 20, azul
            );

            Font subtitulo = FontFactory.getFont(
                    FontFactory.HELVETICA, 10, texto
            );

            Font encabezado = FontFactory.getFont(
                    FontFactory.HELVETICA_BOLD, 11, Color.WHITE
            );

            Font etiqueta = FontFactory.getFont(
                    FontFactory.HELVETICA_BOLD, 10, azul
            );

            Font contenido = FontFactory.getFont(
                    FontFactory.HELVETICA, 10, texto
            );

            Font pequeno = FontFactory.getFont(
                    FontFactory.HELVETICA, 9, texto
            );

            // ENCABEZADO

            Paragraph tituloPDF = new Paragraph(
                    "CONSTANCIA DE BAJA DE USUARIO", titulo
            );

            tituloPDF.setAlignment(Element.ALIGN_CENTER);
            tituloPDF.setSpacingAfter(8);
            documento.add(tituloPDF);

            Paragraph institucion = new Paragraph(
                    "SISTEMA DE GESTIÓN ACADÉMICA", subtitulo
            );

            institucion.setAlignment(Element.ALIGN_CENTER);
            institucion.setSpacingAfter(18);
            documento.add(institucion);

            LineSeparator linea = new LineSeparator();
            linea.setLineColor(azul);
            linea.setLineWidth(2);
            documento.add(linea);

            documento.add(new Paragraph(" "));

            // INFORMACIÓN DEL USUARIO

            PdfPTable tablaUsuario = new PdfPTable(2);
            tablaUsuario.setWidthPercentage(100);
            tablaUsuario.setWidths(new float[]{30, 70});
            tablaUsuario.setSpacingBefore(8);
            tablaUsuario.setSpacingAfter(18);

            PdfPCell tituloUsuario = new PdfPCell(
                    new Phrase("INFORMACIÓN DEL USUARIO", encabezado)
            );

            tituloUsuario.setColspan(2);
            tituloUsuario.setBackgroundColor(azul);
            tituloUsuario.setPadding(9);
            tituloUsuario.setBorder(Rectangle.NO_BORDER);
            tablaUsuario.addCell(tituloUsuario);

            agregarFila(tablaUsuario, "Nombre de usuario", nombreUsuario,
                    etiqueta, contenido, gris);

            agregarFila(tablaUsuario, "Rol", rol,
                    etiqueta, contenido, gris);

            agregarFila(tablaUsuario, "Estado", "BAJA",
                    etiqueta, contenido, gris);

            // DETALLES DE LA BAJA

            PdfPTable tablaBaja = new PdfPTable(2);
            tablaBaja.setWidthPercentage(100);
            tablaBaja.setWidths(new float[]{30, 70});
            tablaBaja.setSpacingAfter(18);

            PdfPCell tituloBaja = new PdfPCell(
                    new Phrase("DETALLES DE LA BAJA", encabezado)
            );

            tituloBaja.setColspan(2);
            tituloBaja.setBackgroundColor(azul);
            tituloBaja.setPadding(9);
            tituloBaja.setBorder(Rectangle.NO_BORDER);
            tablaBaja.addCell(tituloBaja);

            agregarFila(tablaBaja, "Fecha y hora",
                    fecha.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")),
                    etiqueta, contenido, gris);

            agregarFila(tablaBaja, "Motivo", motivo,
                    etiqueta, contenido, gris);

            agregarFila(tablaBaja, "Administrador responsable", administrador,
                    etiqueta, contenido, gris);

            documento.add(tablaUsuario);
            documento.add(tablaBaja);

            // OBSERVACIONES

            Paragraph tituloObservaciones = new Paragraph(
                    "OBSERVACIONES", etiqueta
            );

            tituloObservaciones.setSpacingAfter(7);
            documento.add(tituloObservaciones);

            PdfPCell celdaObservaciones = new PdfPCell(
                    new Phrase(
                            observaciones == null || observaciones.trim().isEmpty()
                            ? "Sin observaciones."
                            : observaciones,
                            contenido
                    )
            );

            celdaObservaciones.setBackgroundColor(gris);
            celdaObservaciones.setPadding(12);
            celdaObservaciones.setBorderColor(new Color(210, 215, 220));
            celdaObservaciones.setMinimumHeight(55);

            PdfPTable tablaObservaciones = new PdfPTable(1);
            tablaObservaciones.setWidthPercentage(100);
            tablaObservaciones.addCell(celdaObservaciones);

            documento.add(tablaObservaciones);

            // CONFIRMACIÓN

            Paragraph confirmacion = new Paragraph(
                    "\nLa baja del usuario ha sido registrada "
                    + "correctamente en el sistema.",
                    contenido
            );

            confirmacion.setAlignment(Element.ALIGN_CENTER);
            confirmacion.setSpacingBefore(12);
            confirmacion.setSpacingAfter(35);

            documento.add(confirmacion);

            // ESPACIOS PARA FIRMAS

            PdfPTable tablaFirmas = new PdfPTable(2);
            tablaFirmas.setWidthPercentage(100);
            tablaFirmas.setWidths(new float[]{50, 50});

            PdfPCell firmaAdmin = new PdfPCell(
                    new Phrase(
                            "____________________________\n"
                            + "Firma del administrador\n"
                            + administrador,
                            pequeno
                    )
            );

            PdfPCell firmaResponsable = new PdfPCell(
                    new Phrase(
                            "____________________________\n"
                            + "Firma del responsable",
                            pequeno
                    )
            );

            firmaAdmin.setBorder(Rectangle.NO_BORDER);
            firmaResponsable.setBorder(Rectangle.NO_BORDER);

            firmaAdmin.setHorizontalAlignment(Element.ALIGN_CENTER);
            firmaResponsable.setHorizontalAlignment(Element.ALIGN_CENTER);

            firmaAdmin.setHorizontalAlignment(Element.ALIGN_CENTER);
            firmaAdmin.setPadding(8);
            firmaResponsable.setPadding(8);

            tablaFirmas.addCell(firmaAdmin);
            tablaFirmas.addCell(firmaResponsable);

            documento.add(tablaFirmas);

            // FECHA DE EMISIÓN

            Paragraph emision = new Paragraph(
                    "\nDocumento generado el "
                    + LocalDateTime.now().format(
                            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")),
                    pequeno
            );

            emision.setAlignment(Element.ALIGN_RIGHT);
            documento.add(emision);

        } finally {
            if (documento.isOpen()) {
                documento.close();
            }
        }

        return ruta;
    }

    private static void agregarFila(
            PdfPTable tabla,
            String nombre,
            String valor,
            Font fuenteEtiqueta,
            Font fuenteContenido,
            Color fondo) {

        PdfPCell celdaNombre = new PdfPCell(
                new Phrase(nombre, fuenteEtiqueta)
        );

        celdaNombre.setBackgroundColor(fondo);
        celdaNombre.setPadding(9);
        celdaNombre.setBorderColor(new Color(220, 225, 230));

        PdfPCell celdaValor = new PdfPCell(
                new Phrase(valor == null ? "" : valor, fuenteContenido)
        );

        celdaValor.setPadding(9);
        celdaValor.setBorderColor(new Color(220, 225, 230));

        tabla.addCell(celdaNombre);
        tabla.addCell(celdaValor);
    }
}
