
package proyecto_gdi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

public class CrearAdministrador {

    public static void main(String[] args) {

        try (Connection conexion = Conexion.conectar()) {

            // Verificar si ya existe el administrador
            String consulta = "SELECT COUNT(*) FROM usuario "
                            + "WHERE nombre_usuario = 'admin'";

            try (PreparedStatement ps = conexion.prepareStatement(consulta);
                 ResultSet rs = ps.executeQuery()) {

                rs.next();

                if (rs.getInt(1) > 0) {
                    JOptionPane.showMessageDialog(null,
                        "La cuenta de administrador ya existe.");
                    return;
                }
            }

            // Solicitar contraseña
            JPasswordField campoContrasena = new JPasswordField();
            int opcion = JOptionPane.showConfirmDialog(
                null,
                campoContrasena,
                "Establecer contraseña del administrador",
                JOptionPane.OK_CANCEL_OPTION
            );

            if (opcion != JOptionPane.OK_OPTION) {
                return;
            }

            String contrasena = new String(
                campoContrasena.getPassword()
            );

            if (contrasena.length() < 4) {
                JOptionPane.showMessageDialog(null,
                    "La contraseña debe tener al menos 10 caracteres.");
                return;
            }

            // Generar hash de la contraseña
            String hash = Seguridad.generarHash(contrasena);

            // Registrar administrador
            String insertar = "INSERT INTO usuario "
                + "(nombre_usuario, contrasena, rol, estado) "
                + "VALUES (?, ?, 'ADMIN', 'ACTIVO')";

            try (PreparedStatement ps =
                    conexion.prepareStatement(insertar)) {

                ps.setString(1, "admin");
                ps.setString(2, hash);
                ps.executeUpdate();
            }

            JOptionPane.showMessageDialog(null,
                "Administrador creado correctamente.\n"
                + "Usuario: admin");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                "Error al crear el administrador: "
                + e.getMessage());
        }
    }
}
