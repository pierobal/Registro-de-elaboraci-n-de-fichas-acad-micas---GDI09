
package proyecto_gdi;

import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class Seguridad {

    private static final int ITERACIONES = 120000;
    private static final int LONGITUD_HASH = 256;

    public static String generarHash(String contrasena) {
        try {
            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);

            KeySpec spec = new PBEKeySpec(
                contrasena.toCharArray(),
                salt,
                ITERACIONES,
                LONGITUD_HASH
            );

            SecretKeyFactory factory =
                SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            byte[] hash = factory.generateSecret(spec).getEncoded();

            return "pbkdf2$" + ITERACIONES + "$"
                + Base64.getEncoder().encodeToString(salt) + "$"
                + Base64.getEncoder().encodeToString(hash);

        } catch (Exception e) {
            throw new RuntimeException("Error al proteger la contraseña", e);
        }
    }

    public static boolean verificarContrasena(
            String contrasena, String hashGuardado) {

        try {
            String[] partes = hashGuardado.split("\\$");

            if (partes.length != 4 || !partes[0].equals("pbkdf2")) {
                return false;
            }

            int iteraciones = Integer.parseInt(partes[1]);
            byte[] salt = Base64.getDecoder().decode(partes[2]);
            byte[] hashOriginal = Base64.getDecoder().decode(partes[3]);

            KeySpec spec = new PBEKeySpec(
                contrasena.toCharArray(),
                salt,
                iteraciones,
                hashOriginal.length * 8
            );

            SecretKeyFactory factory =
                SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            byte[] hashNuevo = factory.generateSecret(spec).getEncoded();

            return java.security.MessageDigest.isEqual(
                hashOriginal, hashNuevo
            );

        } catch (Exception e) {
            return false;
        }
    }
}
