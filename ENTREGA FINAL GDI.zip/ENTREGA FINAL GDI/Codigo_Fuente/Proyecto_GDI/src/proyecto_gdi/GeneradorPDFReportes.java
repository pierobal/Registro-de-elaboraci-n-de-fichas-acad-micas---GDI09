
package proyecto_gdi;

import com.lowagie.text.Document;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Element;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.draw.LineSeparator;

import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.table.TableModel;

public class GeneradorPDFReportes {

    public static String generarPDF(
            TableModel modelo,
            String nombreReporte) throws Exception {

        if (modelo.getRowCount() == 0) {
            throw new Exception("No hay datos para generar el PDF.");
        }

        String carpeta = System.getProperty("user.home")
                + File.separator + "Documents"
                + File.separator + "Reportes_GDI";

        File directorio = new File(carpeta);

        if (!directorio.exists() && !directorio.mkdirs()) {
            throw new Exception("No se pudo crear la carpeta de reportes.");
        }

        LocalDateTime fecha = LocalDateTime.now();

        String nombreArchivo = "Reporte_"
                + fecha.format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"))
                + ".pdf";

        String ruta = carpeta + File.separator + nombreArchivo;

        Document documento = new Document(
                PageSize.A4.rotate(), 35, 35, 40, 40);

        try {
            PdfWriter.getInstance(
                    documento, new FileOutputStream(ruta));

            documento.open();

            Color azul = new Color(31, 78, 121);
            Color gris = new Color(242, 245, 248);
            Color texto = new Color(55, 65, 81);

            Font titulo = FontFactory.getFont(
                    FontFactory.HELVETICA_BOLD, 18, azul);

            Font subtitulo = FontFactory.getFont(
                    FontFactory.HELVETICA, 10, texto);

            Font encabezado = FontFactory.getFont(
                    FontFactory.HELVETICA_BOLD, 9, Color.WHITE);

            Font contenido = FontFactory.getFont(
                    FontFactory.HELVETICA, 8, texto);

            Paragraph tituloPDF = new Paragraph(
                    "REPORTE DEL SISTEMA DE GESTIÓN ACADÉMICA",
                    titulo);

            tituloPDF.setAlignment(Element.ALIGN_CENTER);
            tituloPDF.setSpacingAfter(8);
            documento.add(tituloPDF);

            Paragraph nombre = new Paragraph(
                    nombreReporte.toUpperCase(), subtitulo);

            nombre.setAlignment(Element.ALIGN_CENTER);
            nombre.setSpacingAfter(8);
            documento.add(nombre);

            Paragraph fechaPDF = new Paragraph(
                    "Fecha de generación: "
                    + fecha.format(DateTimeFormatter.ofPattern(
                            "dd/MM/yyyy HH:mm:ss")),
                    subtitulo);

            fechaPDF.setAlignment(Element.ALIGN_RIGHT);
            fechaPDF.setSpacingAfter(15);
            documento.add(fechaPDF);

            LineSeparator linea = new LineSeparator();
            linea.setLineColor(azul);
            linea.setLineWidth(2);
            documento.add(linea);

            documento.add(new Paragraph(" "));

            int columnas = modelo.getColumnCount();

            PdfPTable tablaPDF = new PdfPTable(columnas);
            tablaPDF.setWidthPercentage(100);
            tablaPDF.setHeaderRows(1);
            tablaPDF.setSplitRows(false);
            tablaPDF.setKeepTogether(false);

            for (int i = 0; i < columnas; i++) {

                PdfPCell celda = new PdfPCell(
                        new Phrase(modelo.getColumnName(i), encabezado));

                celda.setBackgroundColor(azul);
                celda.setPadding(7);
                celda.setHorizontalAlignment(Element.ALIGN_CENTER);

                tablaPDF.addCell(celda);
            }

            for (int fila = 0; fila < modelo.getRowCount(); fila++) {

                for (int columna = 0; columna < columnas; columna++) {

                    Object valor = modelo.getValueAt(fila, columna);

                    PdfPCell celda = new PdfPCell(
                            new Phrase(
                                    valor == null ? "" : valor.toString(),
                                    contenido));

                    celda.setPadding(6);
                    celda.setBackgroundColor(
                            fila % 2 == 0 ? gris : Color.WHITE);

                    celda.setBorderColor(new Color(220, 225, 230));

                    tablaPDF.addCell(celda);
                }
            }

            documento.add(tablaPDF);

            Paragraph total = new Paragraph(
                    "Total de registros: " + modelo.getRowCount(),
                    subtitulo);

            total.setAlignment(Element.ALIGN_RIGHT);
            total.setSpacingBefore(10);
            total.setKeepTogether(true);

            documento.add(total);

            Paragraph pie = new Paragraph(
                    "Documento generado por el Sistema de Gestión Académica.",
                    subtitulo);

            pie.setAlignment(Element.ALIGN_CENTER);
            pie.setSpacingBefore(15);

            documento.add(pie);

        } finally {

            if (documento.isOpen()) {
                documento.close();
            }
        }

        return ruta;
    }
}
